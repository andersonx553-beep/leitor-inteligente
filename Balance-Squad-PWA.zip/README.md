# Balance Squad

PWA simples para sorteio e equilíbrio de times de futebol/futsal.

## Arquivos
- `index.html` — aplicativo
- `manifest.json` — configuração PWA
- `sw.js` — cache/offline
- `icon.svg` — ícone

## Teste local
O PWA precisa ser servido por HTTP/HTTPS; não abra o `index.html` diretamente pelo `file://`.

Exemplo:
`python3 -m http.server 8080`

Depois abra:
`http://localhost:8080`

## GitHub Pages
Depois de publicar o conteúdo em uma hospedagem HTTPS, o navegador poderá oferecer a instalação do PWA.
